﻿var aspMultiselectOptions = {
    includeSelectAllOption: true,
    enableFiltering: true,
    allSelectedText: "Все",
    nonSelectedText: "Выберите",
    nSelectedText: " выбрано",
    selectAllText: "Выбрать все",
    enableCaseInsensitiveFiltering: true,
    filterPlaceholder: "Поиск",
    maxHeight: 200,
    buttonWidth: 264,
    numberDisplayed: 1
};
var aspMultiselectOptionsForRegion = {
    includeSelectAllOption: true,
    enableFiltering: true,
    allSelectedText: "Все",
    nonSelectedText: "Выберите",
    nSelectedText: " выбрано",
    selectAllText: "Выбрать все",
    enableCaseInsensitiveFiltering: true,
    filterPlaceholder: "Поиск региона",
    maxHeight: 200,
    buttonWidth: 264,
    numberDisplayed: 1
};
var aspselectOptions = {
    includeSelectAllOption: true,
    enableFiltering: true,
    allSelectedText: "Все",
    nonSelectedText: "Выберите",
    nSelectedText: " выбрано",
    selectAllText: "Выбрать все",
    enableCaseInsensitiveFiltering: true,
    filterPlaceholder: "Поиск региона",
    maxHeight: 200,
    buttonWidth: 264,
    numberDisplayed: 1
};
