﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Smartsp.aspire.dashborad.Models
{
    public class ChartSerie
    {
        public string name { get; set; }
        public List<decimal> data { get; set; }

    }
}